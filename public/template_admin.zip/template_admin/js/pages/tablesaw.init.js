

/*
Template Name: Uplon - Responsive Bootstrap 4 Admin Dashboard
Author: CoderThemes
Version: 2.0.0
Website: https://coderthemes.com/
Contact: support@coderthemes.com
File: Tablesaw init js
*/

$( function(){
    $( document ).trigger( "enhance.tablesaw" );
});
