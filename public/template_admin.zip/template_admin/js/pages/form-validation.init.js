
/*
Template Name: Uplon - Responsive Bootstrap 4 Admin Dashboard
Author: CoderThemes
Version: 2.0.0
Website: https://coderthemes.com/
Contact: support@coderthemes.com
File: Form validation init js
*/

$(document).ready(function() {
    $('.parsley-examples').parsley();
});

